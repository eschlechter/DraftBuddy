//
//  DraftPlayers.swift
//  DraftBuddy
//
//  Created by Eleanor Schlechter on 12/13/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
