//
//  MyTeam.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class MyTeam: UIViewController {
    
    // MARK: - Variables
    @IBOutlet weak var budget: UILabel!
    
        // Name
    @IBOutlet weak var firstDraftedName: UILabel!
    @IBOutlet weak var secondDraftedName: UILabel!
    @IBOutlet weak var thirdDraftedName: UILabel!
    @IBOutlet weak var fourthDraftedName: UILabel!
    @IBOutlet weak var fifthDraftedName: UILabel!
    @IBOutlet weak var sixthDraftedName: UILabel!
    @IBOutlet weak var seventhDraftedName: UILabel!
    @IBOutlet weak var eighthDraftedName: UILabel!
    @IBOutlet weak var ninthDraftedName: UILabel!
    @IBOutlet weak var tenthDraftedName: UILabel!
    @IBOutlet weak var eleventhDraftedName: UILabel!
    
        // Position
    @IBOutlet weak var firstDraftedPosition: UILabel!
    @IBOutlet weak var secondDraftedPosition: UILabel!
    @IBOutlet weak var thirdDraftedPosition: UILabel!
    @IBOutlet weak var fourthDraftedPosition: UILabel!
    @IBOutlet weak var fifthDraftedPosition: UILabel!
    @IBOutlet weak var sixthDraftedPosition: UILabel!
    @IBOutlet weak var seventhDraftedPosition: UILabel!
    @IBOutlet weak var eighthDraftedPosition: UILabel!
    @IBOutlet weak var ninthDraftedPosition: UILabel!
    @IBOutlet weak var tenthDraftedPosition: UILabel!
    @IBOutlet weak var eleventhDraftedPosition: UILabel!
    
        // Salary
    @IBOutlet weak var firstDraftedSalary: UILabel!
    @IBOutlet weak var secondDraftedSalary: UILabel!
    @IBOutlet weak var thirdDraftedSalary: UILabel!
    @IBOutlet weak var fourthDraftedSalary: UILabel!
    @IBOutlet weak var fifthDraftedSalary: UILabel!
    @IBOutlet weak var sixthDraftedSalary: UILabel!
    @IBOutlet weak var seventhDraftedSalary: UILabel!
    @IBOutlet weak var eighthDraftedSalary: UILabel!
    @IBOutlet weak var ninthDraftedSalary: UILabel!
    @IBOutlet weak var tenthDraftedSalary: UILabel!
    @IBOutlet weak var eleventhDraftedSalary: UILabel!
   
    
    // MARK: - Given Material
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    /*
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
     
     // Configure the cell...
     
     return cell
     }
     */
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */

}
