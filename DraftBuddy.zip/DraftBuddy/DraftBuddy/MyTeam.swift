//
//  MyTeam.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class MyTeam: UIViewController {
    
    // MARK: - Variables
    @IBOutlet weak var budget: UILabel!
    
    var myTeam: [String?] = []
    
        // Name
    @IBOutlet weak var firstDraftedName: UILabel!
    @IBOutlet weak var secondDraftedName: UILabel!
    @IBOutlet weak var thirdDraftedName: UILabel!
    @IBOutlet weak var fourthDraftedName: UILabel!
    @IBOutlet weak var fifthDraftedName: UILabel!
    @IBOutlet weak var sixthDraftedName: UILabel!
    @IBOutlet weak var seventhDraftedName: UILabel!
    @IBOutlet weak var eighthDraftedName: UILabel!
    @IBOutlet weak var ninthDraftedName: UILabel!
    @IBOutlet weak var tenthDraftedName: UILabel!
    @IBOutlet weak var eleventhDraftedName: UILabel!
    @IBOutlet weak var twelfthDraftedName: UILabel!
    
        // Position
    @IBOutlet weak var firstDraftedPosition: UILabel!
    @IBOutlet weak var secondDraftedPosition: UILabel!
    @IBOutlet weak var thirdDraftedPosition: UILabel!
    @IBOutlet weak var fourthDraftedPosition: UILabel!
    @IBOutlet weak var fifthDraftedPosition: UILabel!
    @IBOutlet weak var sixthDraftedPosition: UILabel!
    @IBOutlet weak var seventhDraftedPosition: UILabel!
    @IBOutlet weak var eighthDraftedPosition: UILabel!
    @IBOutlet weak var ninthDraftedPosition: UILabel!
    @IBOutlet weak var tenthDraftedPosition: UILabel!
    @IBOutlet weak var eleventhDraftedPosition: UILabel!
    @IBOutlet weak var twelfthDraftedPosition: UILabel!
    
        // Salary
    @IBOutlet weak var firstDraftedSalary: UILabel!
    @IBOutlet weak var secondDraftedSalary: UILabel!
    @IBOutlet weak var thirdDraftedSalary: UILabel!
    @IBOutlet weak var fourthDraftedSalary: UILabel!
    @IBOutlet weak var fifthDraftedSalary: UILabel!
    @IBOutlet weak var sixthDraftedSalary: UILabel!
    @IBOutlet weak var seventhDraftedSalary: UILabel!
    @IBOutlet weak var eighthDraftedSalary: UILabel!
    @IBOutlet weak var ninthDraftedSalary: UILabel!
    @IBOutlet weak var tenthDraftedSalary: UILabel!
    @IBOutlet weak var eleventhDraftedSalary: UILabel!
    @IBOutlet weak var twelfthDraftedSalary: UILabel!
   
    
    // MARK: - Given Material
    override func viewDidLoad() {
        super.viewDidLoad()

        /*
         Below the labels are updated to properly display the data pulled from the darft tab.
         Unfortuantely the segue would not run correctly, so this will not appear in the simulator as planned.
         You will see the if statements correspond to the length of the array transferred over from the draft tab.
         This will allow each player to be updated, one at a time.
        */
        
        /*
        if (myTeam.count >= 3) {
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            
            var salaries = Int(one!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 6){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            
            var salaries = Int(one! + two!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 9){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            
            var salaries = Int(one! + two! + three!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 12){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 15){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 18){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            sixthDraftedName.text = myTeam[15]
            sixthDraftedPosition.text = myTeam[16]
            sixthDraftedSalary.text = myTeam[17]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            let six = Int(sixthDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five! + six!)
            let budget = 50000000 - salaries
             */
        }
        else if (myTeam.count >= 21){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            sixthDraftedName.text = myTeam[15]
            sixthDraftedPosition.text = myTeam[16]
            sixthDraftedSalary.text = myTeam[17]
            seventhDraftedName.text = myTeam[18]
            seventhDraftedPosition.text = myTeam[19]
            seventhDraftedSalary.text = myTeam[20]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            let six = Int(sixthDraftedSalary.text!)
            let seven = Int(seventhDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five! + six! + seven!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 24){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            sixthDraftedName.text = myTeam[15]
            sixthDraftedPosition.text = myTeam[16]
            sixthDraftedSalary.text = myTeam[17]
            seventhDraftedName.text = myTeam[18]
            seventhDraftedPosition.text = myTeam[19]
            seventhDraftedSalary.text = myTeam[20]
            eighthDraftedName.text = myTeam[21]
            eighthDraftedPosition.text = myTeam[22]
            eighthDraftedSalary.text = myTeam[23]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            let six = Int(sixthDraftedSalary.text!)
            let seven = Int(seventhDraftedSalary.text!)
            let eight = Int(eighthDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five! + six! + seven! + eight!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 27){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            sixthDraftedName.text = myTeam[15]
            sixthDraftedPosition.text = myTeam[16]
            sixthDraftedSalary.text = myTeam[17]
            seventhDraftedName.text = myTeam[18]
            seventhDraftedPosition.text = myTeam[19]
            seventhDraftedSalary.text = myTeam[20]
            eighthDraftedName.text = myTeam[21]
            eighthDraftedPosition.text = myTeam[22]
            eighthDraftedSalary.text = myTeam[23]
            ninthDraftedName.text = myTeam[24]
            ninthDraftedPosition.text = myTeam[25]
            ninthDraftedSalary.text = myTeam[26]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            let six = Int(sixthDraftedSalary.text!)
            let seven = Int(seventhDraftedSalary.text!)
            let eight = Int(eighthDraftedSalary.text!)
            let nine = Int(ninthDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five! + six! + seven! + eight! + nine!)
            let budget = 50000000 - salaries
            */
        }
        else if (myTeam.count >= 30){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            sixthDraftedName.text = myTeam[15]
            sixthDraftedPosition.text = myTeam[16]
            sixthDraftedSalary.text = myTeam[17]
            seventhDraftedName.text = myTeam[18]
            seventhDraftedPosition.text = myTeam[19]
            seventhDraftedSalary.text = myTeam[20]
            eighthDraftedName.text = myTeam[21]
            eighthDraftedPosition.text = myTeam[22]
            eighthDraftedSalary.text = myTeam[23]
            ninthDraftedName.text = myTeam[24]
            ninthDraftedPosition.text = myTeam[25]
            ninthDraftedSalary.text = myTeam[26]
            tenthDraftedName.text = myTeam[27]
            tenthDraftedPosition.text = myTeam[28]
            tenthDraftedSalary.text = myTeam[29]
            
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            let six = Int(sixthDraftedSalary.text!)
            let seven = Int(seventhDraftedSalary.text!)
            let eight = Int(eighthDraftedSalary.text!)
            let nine = Int(ninthDraftedSalary.text!)
            let ten = Int(tenthDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five! + six! + seven! + eight! + nine! + ten!)
            let budget = 50000000 - salaries
             */
        }
        else if (myTeam.count >= 33){
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            sixthDraftedName.text = myTeam[15]
            sixthDraftedPosition.text = myTeam[16]
            sixthDraftedSalary.text = myTeam[17]
            seventhDraftedName.text = myTeam[18]
            seventhDraftedPosition.text = myTeam[19]
            seventhDraftedSalary.text = myTeam[20]
            eighthDraftedName.text = myTeam[21]
            eighthDraftedPosition.text = myTeam[22]
            eighthDraftedSalary.text = myTeam[23]
            ninthDraftedName.text = myTeam[24]
            ninthDraftedPosition.text = myTeam[25]
            ninthDraftedSalary.text = myTeam[26]
            tenthDraftedName.text = myTeam[27]
            tenthDraftedPosition.text = myTeam[28]
            tenthDraftedSalary.text = myTeam[29]
            eleventhDraftedName.text = myTeam[30]
            eleventhDraftedPosition.text = myTeam[31]
            eleventhDraftedSalary.text = myTeam[32]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            let six = Int(sixthDraftedSalary.text!)
            let seven = Int(seventhDraftedSalary.text!)
            let eight = Int(eighthDraftedSalary.text!)
            let nine = Int(ninthDraftedSalary.text!)
            let ten = Int(tenthDraftedSalary.text!)
            let eleven = Int(eleventhDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five! + six! + seven! + eight! + nine! + ten! + eleven!)
            let budget = 50000000 - salaries
            */
        }
        else {
            firstDraftedName.text = myTeam[0]
            firstDraftedPosition.text = myTeam[1]
            firstDraftedSalary.text = myTeam[2]
            secondDraftedName.text = myTeam[3]
            secondDraftedPosition.text = myTeam[4]
            secondDraftedSalary.text = myTeam[5]
            thirdDraftedName.text = myTeam[6]
            thirdDraftedPosition.text = myTeam[7]
            thirdDraftedSalary.text = myTeam[8]
            fourthDraftedName.text = myTeam[9]
            fourthDraftedPosition.text = myTeam[10]
            fourthDraftedSalary.text = myTeam[11]
            fifthDraftedName.text = myTeam[12]
            fifthDraftedPosition.text = myTeam[13]
            fifthDraftedSalary.text = myTeam[14]
            sixthDraftedName.text = myTeam[15]
            sixthDraftedPosition.text = myTeam[16]
            sixthDraftedSalary.text = myTeam[17]
            seventhDraftedName.text = myTeam[18]
            seventhDraftedPosition.text = myTeam[19]
            seventhDraftedSalary.text = myTeam[20]
            eighthDraftedName.text = myTeam[21]
            eighthDraftedPosition.text = myTeam[22]
            eighthDraftedSalary.text = myTeam[23]
            ninthDraftedName.text = myTeam[24]
            ninthDraftedPosition.text = myTeam[25]
            ninthDraftedSalary.text = myTeam[26]
            tenthDraftedName.text = myTeam[27]
            tenthDraftedPosition.text = myTeam[28]
            tenthDraftedSalary.text = myTeam[29]
            eleventhDraftedName.text = myTeam[30]
            eleventhDraftedPosition.text = myTeam[31]
            eleventhDraftedSalary.text = myTeam[32]
            twelfthDraftedName.text = myTeam[33]
            twelfthDraftedPosition.text = myTeam[34]
            twelfthDraftedSalary.text = myTeam[36]
            
            /*
            let one = Int(firstDraftedSalary.text!)
            let two = Int(secondDraftedSalary.text!)
            let three = Int(thirdDraftedSalary.text!)
            let four = Int(fourthDraftedSalary.text!)
            let five = Int(fifthDraftedSalary.text!)
            let six = Int(sixthDraftedSalary.text!)
            let seven = Int(seventhDraftedSalary.text!)
            let eight = Int(eighthDraftedSalary.text!)
            let nine = Int(ninthDraftedSalary.text!)
            let ten = Int(tenthDraftedSalary.text!)
            let eleven = Int(eleventhDraftedSalary.text!)
            let twelve = Int(twelfthDraftedSalary.text!)
            
            var salaries = (one! + two! + three! + four! + five! + six! + seven! + eight! + nine! + ten! + eleven! + twelve!)
            let budget = 50000000 - salaries
             */
        }
        */
        
        //budget.text = budget!
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
