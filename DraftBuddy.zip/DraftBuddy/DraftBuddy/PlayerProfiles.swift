//
//  PlayerProfiles.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class PlayerProfileTableViewCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
}


class PlayerProfiles: UITableViewController, UISearchBarDelegate, UISearchDisplayDelegate {
    
    // MARK: - Variables
    
    var allPlayers = AllPlayers()
    var playerInfoToSend: [String?] = []
    
    //@IBOutlet weak var searchBar: UISearchBar!
    //let searchController = UISearchController(searchResultsController: nil)
    
//    var filteredPlayers = [AllPlayers]()
    
    // MARK: - Functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("HERE HERE")
        
        tableView.delegate = self
        tableView.dataSource = self 
        //searchBar.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(allPlayers.playerArray.count)
        return allPlayers.playerArray.count
    }
     
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as! PlayerProfileTableViewCell
        
        let playerName = allPlayers.playerArray[indexPath.row].lastName
        print("playerName: ", playerName)
        cell.nameLabel?.text = playerName
        
        let playerPosition = allPlayers.playerArray[indexPath.row].position
        print ("playerPosition: ", playerPosition)
        cell.positionLabel?.text = playerPosition
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // Get cell label
        let indexPath = IndexPath(row: 0, section: 0)
        let currentCell = tableView.cellForRow(at: indexPath)! as UITableViewCell
        print("indexPath: ", indexPath)
        print("currentCell: ", currentCell)

        //playerInfoToSend = allPlayers.playerArray[indexPath.row]
        //performSegue(withIdentifier: "SpecificPlayerProfile", sender: self)

    }
    
    var uniquePlayerData: [String?] = []
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "SpecificPlayerProfile" {
            let specificPlayerProfile = segue.destination as! SpecificPlayerProfile
            specificPlayerProfile.specificPlayerData = uniquePlayerData
        }
        
    
//    func filterContentForSearchText(searchText: String, scope: String = "All") {
//        filteredPlayers = allPlayers.playerArray.filter { player in
//            return player.lastName.lowercaseString.contains(searchText.lowercased())
//        }
//        
//        tableView.reloadData()
//    }
//
    
}

//
//extension PlayerProfiles: UISearchResultsUpdating {
//    func updateSearchResultsForSearchController(searchController: UISearchController) {
//        filterContentForSearchText(searchText: searchController.searchBar.text!)
//    }
//}
//
//extension PlayerProfiles: UISearchResultsUpdating {
//    @objc(updateSearchResultsForSearchController:) func updateSearchResults(for searchController: UISearchController) {
//        let searchBar = searchController.searchBar
//        let scope = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
//        filterContentForSearchText(searchText: searchController.searchBar.text!, scope: scope)
//    }
//}




    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
}
