//
//  PlayerProfiles.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class PlayerProfileTableViewCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
}


class PlayerProfiles: UITableViewController, UISearchBarDelegate {
    
    // MARK: - Variables
    
    var allPlayers = AllPlayers()
    
    @IBOutlet weak var searchBar: UISearchBar!
    var filteredData: [PlayerData] = []
    
    // MARK: - Functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        
        filteredData = allPlayers.playerArray
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return filteredData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlayerProfileCell", for: indexPath) as! PlayerProfileTableViewCell
        
        let playerName = filteredData[indexPath.row].lastName
        //print("playerName: ", playerName)
        cell.nameLabel?.text = playerName
        
        let playerPosition = filteredData[indexPath.row].position
        //print ("playerPosition: ", playerPosition)
        cell.positionLabel?.text = playerPosition
        
        return cell
    }
    
    
    var uniquePlayerData: PlayerData?
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // Get cell information
        let indexPath = tableView.indexPathForSelectedRow
        print((indexPath?.row)!)
        
        uniquePlayerData = allPlayers.playerArray[(indexPath?.row)!]
        print((uniquePlayerData?.age)!)
        print((uniquePlayerData?.prob1)!)
        
        
        performSegue(withIdentifier: "SpecificPlayerProfile", sender: self)
        
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        
        if segue.identifier == "SpecificPlayerProfile" {
            print("prepare")
            let specificPlayerProfile = segue.destination as! SpecificPlayerProfile
            specificPlayerProfile.specificPlayerData = uniquePlayerData
        }
    }
    
//    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
//        self.searchBar.showsCancelButton = true
//    }
//    
//    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
//        searchBar.showsCancelButton = false
//        searchBar.text = ""
//        searchBar.resignFirstResponder()
//    }
//    
//    func updateSearchResultsForSearchController(searchController: UISearchController) {
//        if let searchText = searchController.searchBar.text {
//            filteredData = searchText.isEmpty ? allPlayers : allPlayers.playerArray.filter({(dataString: String) -> Bool in
//                return dataString.range(of: searchText, options: .caseInsensitive) != nil
//            })
//            
//            tableView.reloadData()
//        }
//    }
}
