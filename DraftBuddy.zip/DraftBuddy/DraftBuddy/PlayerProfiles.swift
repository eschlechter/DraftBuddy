//
//  PlayerProfiles.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class PlayerProfileTableViewCell: UITableViewCell {
    
    // connecting the labels associated with each individual cell
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
}


class PlayerProfiles: UITableViewController, UISearchDisplayDelegate, UISearchBarDelegate {
    
    // MARK: - Variables
    
    // connecting to the All Players class to use the playerArray
    var allPlayers = AllPlayers()
    
    @IBOutlet var tableOfPlayers: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    // the players included in the filtered array after a  last name is searched
    var filteredData: [PlayerData] = []
    
    
    
    
    
    // MARK: - Given
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        self.tableOfPlayers.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    
    // MARK: - Table View 
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // creates the number of rows associated with the number of players 
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // if (tableView == self.searchDisplayController!.searchResultsTableView) {
           // return self.filteredData.count
        // }
        // else {
            return self.allPlayers.playerArray.count
        // }
    }
    
    // configures the cell properties (labels)
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlayerProfileCell", for: indexPath) as! PlayerProfileTableViewCell
        
        /*
        if (tableView == self.searchDisplayController!.searchResultsTableView) {
            let playerName = filteredData[indexPath.row].lastName
            //print("playerName: ", playerName)
            cell.nameLabel?.text = playerName
            
            let playerPosition = filteredData[indexPath.row].position
            //print ("playerPosition: ", playerPosition)
            cell.positionLabel?.text = playerPosition
        }
        else {
         */
            let playerName = allPlayers.playerArray[indexPath.row].lastName
            //print("playerName: ", playerName)
            cell.nameLabel?.text = playerName
            
            let playerPosition = allPlayers.playerArray[indexPath.row].position
            //print ("playerPosition: ", playerPosition)
            cell.positionLabel?.text = playerPosition
        // }
        return cell
    }
    
    
    // the below code creates the code associated with gathering and sending to the Specific Player Profile
    var uniquePlayerData: PlayerData?
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // Get cell information
        let indexPath = tableView.indexPathForSelectedRow
        print((indexPath?.row)!)
        
        
        // Selects one player and all of their associated data 
        uniquePlayerData = allPlayers.playerArray[(indexPath?.row)!]
        print((uniquePlayerData?.age)!)
        print((uniquePlayerData?.prob1)!)
        
        
        performSegue(withIdentifier: "SpecificPlayerProfile", sender: self)
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "SpecificPlayerProfile" {
            print("prepare")
            let specificPlayerProfile = segue.destination as! SpecificPlayerProfile
            specificPlayerProfile.specificPlayerData = uniquePlayerData
        }
    }
    
    
    
    
    
    // MARK: - Search Bar 
    
    /*
     The below code for the search bar does not work because I can not figure out how to change it from Swift2.0 code to Swift3.
     
     func filterTableViewForEnterText(searchText: String) {
     let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchText)
     let array = (self.allPlayers.playerArray as NSArray).filtered(using: searchPredicate)
     self.filteredData = array as! [PlayerData]
     self.tableOfPlayers.reloadData()
     }
     
     private func searchDisplayController(_ controller: UISearchController, shouldReloadTableForSearch searchString: String?) -> Bool {
     self.filterTableViewForEnterText(searchText: searchString!)
     return true
     }
     */
}
