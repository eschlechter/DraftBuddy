//
//  PlayerData.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 12/5/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation

class PlayerData {
    
    // variables shared for all players 
    var salary: Int
    var playerID: String
    var firstName: String
    var lastName: String
    var position: String
    var age: String
    var yearID: String
    var throwingArm: String
    var hits: Int
    var walks: Int
    var homeRuns: Int
    var runs: Int
    var strikeOuts: Int
    var hitByPitch: Int
    var intentionalWalks: Int

    
    // pitcher data only
    var wins: Int
    var losses: Int
    var games: Int
    var gamesStarted: Int
    var saves: Int
    var earnedRuns: Int
    var battersFaced: Int
    var wildPitches: Int
    var balks: Int
    var inningsPitched: Double
    
    var whip: Double
    var baa: Double 

    
    // position data only
    var decade: String
    var battingArm: String
    var singles: Int
    var doubles: Int
    var triples: Int
    var runsBattedIn: Int
    var sacFly: Int
    var atBats: Int
    var plateAppearances: Int
    var sacBunts: Int
    
    var prob1: Double
    var prob2: Double
    var prob3: Double
    var prob4: Double
    var prob0: Double
    var expectSlug: Double
    var obp: Double
    var ops: Double
    var babip: Double
    
    // initializing all variables
    init(data: [String]) {
        salary = Int(data[0])!
        playerID = data[1]
        firstName = data[2]
        lastName = data[3]
        
        // data[4] represents where the position and pitcher data diverge in similarities 
        
        // pitcher data being saved as objects
        if (data[4] == "R" || data[4] == "L") {
            // this is a pitcher
            throwingArm = data[4]
            age = data[5]
            yearID = data[6]
            wins = Int(data[7])!
            losses = Int(data[8])!
            games = Int(data[9])!
            gamesStarted = Int(data[10])!
            saves = Int(data[11])!
            hits = Int(data[12])!
            earnedRuns = Int(data[13])!
            battersFaced = Int(data[14])!
            homeRuns = Int(data[15])!
            walks = Int(data[16])!
            strikeOuts = Int(data[17])!
            intentionalWalks = Int(data[18])!
            wildPitches = Int(data[19])!
            hitByPitch = Int(data[20])!
            balks = Int(data[21])!
            runs = Int(data[22])!
            inningsPitched = Double(data[23])!
            position = data[24]
            
            whip = Double((hits + walks)) / inningsPitched
            baa = Double(hits / (battersFaced - walks - hitByPitch))
            
            
            // dummy values to properly initialize
            decade = ""
            battingArm = "000"
            singles = 000
            doubles = 000
            triples = 000
            runsBattedIn = 000
            sacFly = 000
            atBats = 000
            plateAppearances = 000
            sacBunts = 000
            prob1 = 000
            prob2 = 000
            prob3 = 000
            prob4 = 000
            prob0 = 000
            expectSlug = 000
            obp = 000
            ops = 000
            babip = 000
        }
            
        // position player data being saved as objects
        else {
            // this is a position player
            position = data[4]
            yearID = data[5]
            decade = data[6]
            battingArm = data[7]
            throwingArm = data[8]
            age = data[9]
            singles = Int(data[10])!
            walks = Int(data[11])!
            doubles = Int(data[12])!
            triples = Int(data[13])!
            hits = Int(data[14])!
            homeRuns = Int(data[15])!
            runsBattedIn = Int(data[16])!
            hitByPitch = Int(data[17])!
            sacFly = Int(data[18])!
            strikeOuts = Int(data[19])!
            atBats = Int(data[20])!
            plateAppearances = Int(data[21])!
            intentionalWalks = Int(data[22])!
            runs = Int(data[23])!
            sacBunts = Int(data[24])!
            
            prob1 = Double((singles) / plateAppearances)
            prob2 = Double(doubles / plateAppearances)
            prob3 = Double(triples / plateAppearances)
            prob4 = Double(homeRuns / plateAppearances)
            prob0 = Double(1 - (prob1 + prob2 + prob3 + prob4))
            expectSlug = Double(0*prob0 + 1*prob1 + 2*prob2 + 3*prob3 + 4*prob4)
            obp = Double((hits + hitByPitch + walks) / (atBats + walks + hitByPitch + sacFly))
            ops = Double(expectSlug + obp)
            babip = Double((hits - homeRuns) / (atBats - strikeOuts - homeRuns + sacFly))
            
            
            // dummy values to properly initialize
            wins = 000
            losses = 000
            games = 000
            gamesStarted = 000
            saves = 000
            earnedRuns = 000
            battersFaced = 000
            wildPitches = 000
            balks = 000
            inningsPitched = 000
            whip = 000
            baa = 000
        }
    }
}
