//
//  DraftPlayers.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class DraftTableViewCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
    
    @IBAction func draftedToMyTeam(_ sender: UIButton) {
    }
    
    @IBAction func draftedToOtherTeam(_ sender: UIButton) {
    }
}


class DraftPlayers: UITableViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    // MARK: - Variables
    var allPlayers = AllPlayers()
    
    @IBOutlet weak var pickerFilterByPosition: UIPickerView!
    
    var pickerDataSource = ["1B", "2B", "3B", "SS", "OF", "C", "P", "All Hitters"]
    
    // MARK: - Given
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerFilterByPosition.dataSource = self
        pickerFilterByPosition.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    // MARK: - Table View
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allPlayers.playerArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as! PlayerProfileTableViewCell
        
        let playerName = allPlayers.playerArray[indexPath.row].lastName
        cell.nameLabel?.text = playerName
        
        let playerPosition = allPlayers.playerArray[indexPath.row].position
        cell.positionLabel?.text = playerPosition
        
        return cell
    }
    
    
    // MARK: Picker View
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerDataSource.count;
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerDataSource[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int, _ indexPath: IndexPath) {
        
        if(row == 0) {
            // 1B
            allPlayers.playerArray[indexPath.row].position = "1B"
            self.tableView.reloadData()
        }
            
        else if(row == 1) {
            // 2B
            allPlayers.playerArray[indexPath.row].position = "2B"
            self.tableView.reloadData()
        }
            
        else if(row == 2) {
            // 3B
            allPlayers.playerArray[indexPath.row].position = "3B"
            self.tableView.reloadData()
        }
            
        else if (row == 3) {
            // SS
            allPlayers.playerArray[indexPath.row].position = "SS"
            self.tableView.reloadData()
        }
            
        else if (row == 4) {
            // OF
            allPlayers.playerArray[indexPath.row].position = "OF"
            self.tableView.reloadData()
        }
            
        else if (row == 5) {
            // C
            allPlayers.playerArray[indexPath.row].position = "C"
            self.tableView.reloadData()
        }
            
        else if (row == 6) {
            // P
            allPlayers.playerArray[indexPath.row].position = "P"
            self.tableView.reloadData()
        }
            
        else {
            // ALL HITTERS
            
        }
    }
    
    /*
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
     
     // Configure the cell...
     
     return cell
     }
     */
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
}
