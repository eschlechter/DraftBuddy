//
//  DraftPlayers.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class DraftTableViewCell: UITableViewCell {
    
    // connecting the labels associated with each individual cell
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
}


class DraftPlayers: UITableViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    // MARK: - Variables
    
    // connecting to the All Players class to use the playerArray
    var allPlayers = AllPlayers()
    
    // the players selected to be added to the Team tab
    var myDraftedPlayers: [String?] = []
    
    // the palayers associated with the filter
    var pickedPlayers: [PlayerData?] = []
    
    // picker view connection and associated labels held within the picker view object
    @IBOutlet weak var pickerFilterByPosition: UIPickerView!
    var pickerDataSource = ["1B", "2B", "3B", "SS", "OF", "C", "P", "All Hitters"]
    
    
    
    // MARK: - Given
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        pickerFilterByPosition.dataSource = self
        pickerFilterByPosition.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    // MARK: - Table View
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    // allows the swipe delete button to appear in the table view
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        self.tableView.setEditing(editing, animated: animated)
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        print("editingStyle")
        if editingStyle == .delete {
            allPlayers.playerArray.remove(at: indexPath.row)
            self.tableView.reloadData()
        }
    }
    
    // creates the number of rows associated with the number of players 
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (pickedPlayers.count > 0){
            return pickedPlayers.count
        }
        else {
            return allPlayers.playerArray.count
        }
    }
    
    // configures the cell properties (labels)
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DraftPlayerCell", for: indexPath) as! DraftTableViewCell
        
        if (pickedPlayers.count > 0){
            let playerName = pickedPlayers[indexPath.row]?.lastName
            cell.nameLabel?.text = playerName
            
            let playerPosition = pickedPlayers[indexPath.row]?.position
            cell.positionLabel?.text = playerPosition
        }
        else {
            let playerName = allPlayers.playerArray[indexPath.row].lastName
            cell.nameLabel?.text = playerName
            
            let playerPosition = allPlayers.playerArray[indexPath.row].position
            cell.positionLabel?.text = playerPosition
        }
        
        return cell
    }
    
    // the below two functions were created to set up the data and prepare it to be sent to the team tab, it does not work properly
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("selecting cell")
        
        // Get cell information
        let indexPath = tableView.indexPathForSelectedRow
        print(indexPath)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DraftPlayerCell", for: indexPath!) as! DraftTableViewCell
        
        // search through all of the players and the data until it finds a match with the cell labels
        var i = 0
        while i < allPlayers.playerArray.count {
            if (cell.nameLabel?.text == allPlayers.playerArray[indexPath!.row].lastName){
                if(cell.positionLabel?.text == allPlayers.playerArray[indexPath!.row].position){
                    myDraftedPlayers.append("\(allPlayers.playerArray[indexPath!.row].lastName)")
                    print(allPlayers.playerArray[indexPath!.row].lastName)
                    
                    myDraftedPlayers.append("\(allPlayers.playerArray[indexPath!.row].position)")
                    print(allPlayers.playerArray[i].position)
                    
                    myDraftedPlayers.append("\(allPlayers.playerArray[indexPath!.row].salary)")
                    print(allPlayers.playerArray[i].salary)
                }
            }
            i += 1
        }
        performSegue(withIdentifier: "MyTeam", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "MyTeam" {
            print("prepare")
            let rosterInfo = segue.destination as! MyTeam
            rosterInfo.myTeam = myDraftedPlayers
        }
    }
    
    
    
    
    // MARK: Picker View
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // creates enough rows in the picker view
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerDataSource.count;
    }
    
    // attaches the picker view data names to the appropriate row
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerDataSource[row]
    }
    
    
    /*
     The below code is what I creates to filer the table view.
     Whne runnign the simulator you will note that it does not work.
     Since there isn't any documatation on this online, this is th ebest I could come up with since it made sense to me. 
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int, _ indexPath: IndexPath) {
        if(row == 0) {
            // 1B
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position == "1B") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
            
        else if(row == 1) {
            // 2B
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position == "2B") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
            
        else if(row == 2) {
            // 3B
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position == "3B") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
            
        else if (row == 3) {
            // SS
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position == "SS") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
            
        else if (row == 4) {
            // OF
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position == "OF") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
            
        else if (row == 5) {
            // C
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position == "C") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
            
        else if (row == 6) {
            // P
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position == "P") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
            
        else {
            // ALL HITTERS
            let i = 0
            while i <= allPlayers.playerArray.count {
                if (allPlayers.playerArray[i].position != "P") {
                    pickedPlayers.append(allPlayers.playerArray[i])
                }
            }
            self.tableView.reloadData()
        }
    }
}
