//
//  Pitcher_PlayerData.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/2/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation

class PitcherPlayerData {
    
    var salary: Int
    var playerID: String
    var firstName: String
    var lastName: String
    var throwingArm: String
    var age: Int
    var yearID: Int
    var wins: Int
    var losses: Int
    var games: Int
    var gamesStarted: Int
    var saves: Int
    var hits: Int
    var earnedRuns: Int
    var battersFaced: Int
    var homeRuns: Int
    var walks: Int
    var strikeOuts: Int
    var intentionalWalks: Int
    var wildPitches: Int
    var hitByPitches: Int
    var balks: Int
    var runs: Int
    var inningsPitched: Int
    var position: String
    
    
    init (_ line: String){

        //parse a line
        guard let filePath = Bundle.main.path(forResource: "PositionPlayers", ofType: "csv")
            else {return}
        
        //read the entire file
        var contents = ""
        do {
            contents = try String(contentsOfFile: filePath)
        }
        catch {
            print("File Read Error for file \(filePath)")
            return
        }
        
        // split the String into lines by newline
        let lines = contents.components(separatedBy: CharacterSet.newlines)
        
        // display all lines with a line number at the front
        var lineNumber = 1
        for line in lines {
            print("\(lineNumber): \(line)")
            lineNumber += 1
        }
        
        //PARSING LOOP
        let delim = ","
        if(contents.h)
    }
    
}
