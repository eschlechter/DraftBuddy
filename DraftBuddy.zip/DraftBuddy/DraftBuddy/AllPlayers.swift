//
//  AllPlayers.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 12/6/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation

class AllPlayers {
    
    var playerArray: [PlayerData] = []
    
    init (){
        // read the position players in
        guard let filePath1 = Bundle.main.path(forResource: "PositionPlayers", ofType: "csv")
            else {return}
        
        // read the entire file
        var contents1 = ""
        do {
            contents1 = try String(contentsOfFile: filePath1)
        }
        catch {
            print("File Read Error for file \(filePath1)")
            return
        }
        
        // parsing loop, saving each player in a line
        let lines = contents1.components(separatedBy: .newlines)
        
        for line in lines {
            let items = line.components(separatedBy: ",")
            let player = PlayerData(data: items)
            playerArray.append(player)
        }
        
        
        // read the pitchers in
        guard let filePath2 = Bundle.main.path(forResource: "Pitchers", ofType: "csv")
            else {return}
        
        // read the entire file
        var contents2 = ""
        do {
            contents2 = try String(contentsOfFile: filePath2)
        }
        catch {
            print("File Read Error for file \(filePath2)")
            return
        }
        
        // parsing loop, saving each player in a line
        let lines2 = contents2.components(separatedBy: .newlines)
        
        for line2 in lines2 {
            let items = line2.components(separatedBy: ",")
            let player = PlayerData(data: items)
            playerArray.append(player)
        }
    }
}
