//
//  SpecificPlayerProfile.swift
//  DraftBuddy
//
//  Created by Sammi Schlechter on 11/1/16.
//  Copyright © 2016 Sammi Schlechter. All rights reserved.
//

import Foundation
import UIKit

class SpecificPlayerProfile: UIViewController {
    
    // MARK: - Variables
    
    // the variable that gathers the data sent through the segue 
    var specificPlayerData: PlayerData?
    
    // labels that will display the sent data
    @IBOutlet weak var playerImage: UIImageView!
    @IBOutlet weak var playerName: UILabel!
    @IBOutlet weak var playerPosition: UILabel!
    @IBOutlet weak var playerAge: UILabel!
    @IBOutlet weak var playerSeasonYear: UILabel!

    @IBOutlet weak var playerSalary: UILabel!
    
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label4: UILabel!
    @IBOutlet weak var label5: UILabel!
    @IBOutlet weak var label6: UILabel!
    @IBOutlet weak var label7: UILabel!
    @IBOutlet weak var label8: UILabel!
    @IBOutlet weak var label9: UILabel!
    
    @IBAction func returnToplayerList(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    // MARK: - Given Material
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // allocating what goes with which label
        playerImage.image = UIImage(named: (specificPlayerData?.playerID)!)
        
        playerName.text = (specificPlayerData?.lastName)
        print(specificPlayerData?.lastName)
        
        playerPosition.text = (specificPlayerData?.position)
        print(specificPlayerData?.position)
        
        playerAge.text = (specificPlayerData?.age)
        print(specificPlayerData?.age)
        
        playerSeasonYear.text = (specificPlayerData?.yearID)
        print(specificPlayerData?.yearID)
        
        playerSalary.text = "Salary: $\((specificPlayerData?.salary)!)"
        
        // labels 1-9 will display the data I found pertinent to each position, either pitchers or hitters 
        if (specificPlayerData?.position == "SP"){
            label1.text = "Throwing Arm: \((specificPlayerData?.throwingArm)!)"
            label2.text = "Wins: \((specificPlayerData?.wins)!)"
            label3.text = "Losses: \((specificPlayerData?.losses)!)"
            label4.text = "Walks: \((specificPlayerData?.walks)!)"
            label5.text = "Games PLayed: \((specificPlayerData?.games)!)"
            label6.text = "Innings Pitched: \((specificPlayerData?.inningsPitched)!)"
            label7.text = "Runs: \((specificPlayerData?.runs)!)"
            label8.text = "WHIP: \((specificPlayerData?.whip)!)"
            label9.text = "BAA: \((specificPlayerData?.baa)!)"
        }
        else {
            label1.text = "Batting Arm: \((specificPlayerData?.battingArm)!)"
            label2.text = "Runs: \((specificPlayerData?.runs)!)"
            label3.text = "RBI: \((specificPlayerData?.runsBattedIn)!)"
            label4.text = "Probability of HR: \((specificPlayerData?.prob4)!)"
            label5.text = "Slugging Percentage: \((specificPlayerData?.expectSlug)!)"
            label6.text = "On-Base Plus Slugging: \((specificPlayerData?.ops)!)"
            label7.text = "BABIP: \((specificPlayerData?.babip)!)"
            label8.text = "Plate Appearances: \((specificPlayerData?.plateAppearances)!)"
            label9.text = "Strike Outs: \((specificPlayerData?.strikeOuts)!)"
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
